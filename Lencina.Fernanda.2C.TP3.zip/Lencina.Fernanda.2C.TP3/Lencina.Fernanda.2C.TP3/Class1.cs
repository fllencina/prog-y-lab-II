﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lencina.Fernanda._2C.TP3
{
    public class Class1
    {
    }
}
