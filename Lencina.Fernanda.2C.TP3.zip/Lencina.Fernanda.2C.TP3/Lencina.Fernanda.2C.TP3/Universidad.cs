﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lencina.Fernanda._2C.TP3
{
    public enum EClases
    {
        Programacion,Laboratorio,Legislacion,SPD
    }

    public class Universidad
    {
        private List<Alumno>
    }
}
