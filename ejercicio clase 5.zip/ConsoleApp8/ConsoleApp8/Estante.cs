﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Estante
    {
        Producto[] productos;
        int ubicacionEstante;

        //constructores

        //privado
        private Estante(int capacidad)
        {
            productos = new Producto[capacidad];
        }

        //publico
        public Estante(int capacidad, int ubicacion) : this(capacidad) //llama al constructor privado
        {
            this.ubicacionEstante = ubicacion;
        }

        //getters
        public Producto[] GetProductos()
        {
            return this.productos;
        }

        //metodos
        public static string MostrarEstante(Estante e)
        { //aca tengo el stringBuilder ver
            StringBuilder sb = new StringBuilder();

            Console.WriteLine("======================ESTANTE======================");
            sb.AppendLine("UBICACION: " + e.ubicacionEstante);
            sb.AppendLine("CAPACIDAD: " + e.productos.Length);
            sb.AppendLine("PRODUCTOS:");
            foreach (Producto p in e.productos)
            {
                sb.AppendLine(Producto.MostrarProducto(p));
            }

            return sb.ToString();
        }

        //sobrecarga
        public static bool operator ==(Estante e, Producto p)
        {
            foreach (Producto aux in e.productos)
            {
                if (p == aux)
                {
                    return true;
                }    
            }
            return false;
        }
        public static bool operator !=(Estante e, Producto p)
        {
            return !(e == p);
        }

        public static bool operator +(Estante e, Producto p)
        {
            if (e != p)
            {
                for (int i = 0; i < e.productos.Length; i++)
                {
                    // Busco un espacio vacio
                    if (object.ReferenceEquals(e.productos[i], null))
                    {
                        e.productos[i] = p;
                        return true;
                    }
                }
            }      
            return false;
        }
        public static Estante operator -(Estante e, Producto p)
        {
            for (int i = 0; i < e.productos.Length; i++)
            {
                 
                if (object.ReferenceEquals(e.productos[i], null))
                {
                    if (e == p)
                    {
                        e.productos[i] = null;
                        break;
                    }
                }
            }
            return e;
        }


    }
}
