﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Producto
    {
        protected string codigoDeBarras;
        protected string marca;
        protected float precio;

        //constructor

        public Producto(string marca,string codigo,float precio)
        {
            this.codigoDeBarras = codigo;
            this.marca = marca;
            this.precio = precio;
        }
        // Getters
        public string GetMarca()
        {
            return  this.marca;
        }
        public float GetPrecio()
        {
            return  this.precio;
        }

        //metodos
        public static string MostrarProducto(Producto p)
        {   //buscar string builder y string format
            string cadena = p.codigoDeBarras + " " + p.GetMarca() + " " + Convert.ToString(p.precio);
            return cadena; 
        }
        //explicito
        public static explicit  operator string (Producto p)
        {
            return p.codigoDeBarras;
        }

        //sobrecarga de operadores
        public static bool operator ==(Producto p1,Producto p2)
        {
            if (object.ReferenceEquals(p1, null) || object.ReferenceEquals(p2, null))
            {
                return false;
            }

            else
            {
                if (p1.marca == p2.marca && p1.codigoDeBarras == p2.codigoDeBarras)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool operator !=(Producto p1, Producto p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Producto p,string marca)
        {
            if (p.GetMarca() == marca)
            {
                return true;
            }
            else
                return false;
        }
        public static bool operator !=(Producto p, string marca)
        {
            return !(p == marca);
        }

    }
}
