﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IO;

namespace ejercicio_42
{
    class Program
    {
        static void Main(string[] args)
        {
           
            string ruta = String.Format(@"C:\Users\Fernanda\Desktop\Prog y Lab 2 Federico Davila\Mi Git actual\ejercicio 54\{0}{1}{2}-{3}{4}.txt", DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute);
            try
            {
                OtraClase aux = new OtraClase();
                aux.MetodoInstancia();
            }
            catch (Exception e)
            {
                if (!object.ReferenceEquals(e.InnerException, null))
                {
                    do
                    {
                        ArchivoTexto.Guardar(ruta, e.Message);
                        e = e.InnerException;
                    } while (!object.ReferenceEquals(e, null));
                }
            }
            string textoLeido=ArchivoTexto.Leer(ruta);
            Console.WriteLine(textoLeido);
            Console.ReadKey();
        }
    }
    public class MiClase
    {
        public static void MetodoEstatico()
        {
            try
            {
                int aux = 0;
                int res = 10 / aux;
            }
            catch (DivideByZeroException e)
            {
                throw e;
            }
        }
        public MiClase()
        {
            try
            {
                MiClase.MetodoEstatico();
            }
            catch (DivideByZeroException e)
            {
                throw e;
            }
        }
        public MiClase(int a)
        {
            try
            {
                new MiClase();
            }
            catch (DivideByZeroException e)
            {
                throw new UnaExcepcion("esta clase lo captura y lugo se muestra lo resgistrado en inner", e);
            }
        }
    }
    public class OtraClase
    {
        public void MetodoInstancia()
        {
            try
            {
                new MiClase(0);
            }
            catch (UnaExcepcion e)
            {
                MiExcepcion ex = new MiExcepcion("esta  clase re-lanza la excepcion", e);
                throw ex;
            }
        }
    }
}

